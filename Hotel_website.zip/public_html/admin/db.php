<?php
$con = mysqli_connect("localhost","id7419655_root","password","id7419655_hotel") or die(mysql_error());

?>