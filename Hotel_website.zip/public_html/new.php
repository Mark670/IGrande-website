<form action='' method='POST'>
<?php

$con = mysqli_connect("localhost","root","password","hotel");
 
$query  = "SELECT * FROM login WHERE usrname = 'root' AND pass = 'password'";
$result = mysqli_query($con,$query);
if($result === FALSE) { 
    die(mysql_error()); // TODO: better error handling
}
while ($row = mysql_fetch_array($result)) {
    echo "  To delete user   <b>" . $row['username'] . "</b>  Click on the number <input type='submit' name='delete' value='" . $row['id'] . "' /><br/>";
}

if (isset($_POST['delete'])) {
    $user = $_POST['delete'];
    $delet_query = mysqli_query("DELETE FROM users WHERE id = $user ") or die(mysql_error());

    if ($delet_query) {
        echo 'user with id ' . $user . ' is removed from your table, to refresh your page, click' . '<a href=' . $_SERVER["PHP_SELF"] . ' > here </a>';
    }
}
?>
</form>